# Library Management System (Java + MySQL + JDBC)

A simple **console-based** Library Management System built with **Java 17**, **MySQL**, and **JDBC**.
Use it as a starter project for internships/placements where a Java solution is required.

## Features
- Add a book
- View all books
- Search a book by **ID** or **Title**
- Delete a book
- Clean DAO-style code and PreparedStatements

## Tech Stack
- Java 17
- MySQL (via JDBC Connector/J)
- Maven

## Getting Started

### 1) Clone
```bash
git clone https://github.com/ravi-3690/library-management-java.git
cd library-management-java
```

### 2) Database Setup
Create database & table:
```sql
-- Run this in MySQL
CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

CREATE TABLE IF NOT EXISTS books (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(100) NOT NULL,
  author VARCHAR(100) NOT NULL,
  year INT
);
```

### 3) Configure DB Credentials
Edit **`src/main/resources/application.properties`**:
```
db.url=jdbc:mysql://localhost:3306/library_db
db.user=YOUR_MYSQL_USER
db.password=YOUR_MYSQL_PASSWORD
```

### 4) Build & Run
```bash
mvn clean package
# Run from Maven (dev)
mvn -q exec:java -Dexec.mainClass="com.ravi.library.Main" -Dexec.cleanupDaemonThreads=false
# Or run the jar
java -cp "target/library-management-java-1.0.0.jar:~/.m2/repository/com/mysql/mysql-connector-j/8.3.0/mysql-connector-j-8.3.0.jar" com.ravi.library.Main
```

> **Note**: If `exec:java` is not available, you can add the Maven Exec plugin or run via your IDE (IntelliJ/Eclipse).

## Project Structure
```
library-management-java
├─ pom.xml
├─ sql/
│  └─ library.sql
├─ src/
│  └─ main/
│     ├─ java/com/ravi/library/
│     │  ├─ Main.java
│     │  ├─ Book.java
│     │  ├─ LibraryManager.java
│     │  └─ DBConnection.java
│     └─ resources/
│        └─ application.properties
└─ README.md
```

## Sample Usage
```
Library Management System
1. Add Book
2. View All Books
3. Search Book by ID
4. Search Book by Title
5. Delete Book
6. Exit
Enter choice: 1
Enter Title: Java Basics
Enter Author: Ravi Kumar
Enter Year: 2025
Book added successfully!
```

## License
MIT
