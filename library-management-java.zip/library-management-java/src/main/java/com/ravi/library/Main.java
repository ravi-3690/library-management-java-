package com.ravi.library;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final LibraryManager manager = new LibraryManager();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add Book");
            System.out.println("2. View All Books");
            System.out.println("3. Search Book by ID");
            System.out.println("4. Search Book by Title");
            System.out.println("5. Delete Book");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            String choice = sc.nextLine().trim();

            try {
                switch (choice) {
                    case "1" -> addBook(sc);
                    case "2" -> viewAll();
                    case "3" -> searchById(sc);
                    case "4" -> searchByTitle(sc);
                    case "5" -> deleteBook(sc);
                    case "6" -> { System.out.println("Goodbye!"); return; }
                    default -> System.out.println("Invalid choice. Try again.");
                }
            } catch (SQLException e) {
                System.out.println("DB Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void addBook(Scanner sc) throws SQLException {
        System.out.print("Enter Title: ");
        String title = sc.nextLine();
        System.out.print("Enter Author: ");
        String author = sc.nextLine();
        System.out.print("Enter Year: ");
        int year = Integer.parseInt(sc.nextLine());
        int newId = manager.addBook(new Book(title, author, year));
        System.out.println(newId > 0 ? "Book added with ID: " + newId : "Failed to add book.");
    }

    private static void viewAll() throws SQLException {
        List<Book> books = manager.getAllBooks();
        if (books.isEmpty()) {
            System.out.println("No books found.");
        } else {
            books.forEach(System.out::println);
        }
    }

    private static void searchById(Scanner sc) throws SQLException {
        System.out.print("Enter Book ID: ");
        int id = Integer.parseInt(sc.nextLine());
        Book b = manager.findBookById(id);
        System.out.println(b != null ? b : "Book not found");
    }

    private static void searchByTitle(Scanner sc) throws SQLException {
        System.out.print("Enter Title (partial allowed): ");
        String title = sc.nextLine();
        List<Book> books = manager.findBooksByTitle(title);
        if (books.isEmpty()) {
            System.out.println("No matching books.");
        } else {
            books.forEach(System.out::println);
        }
    }

    private static void deleteBook(Scanner sc) throws SQLException {
        System.out.print("Enter Book ID to delete: ");
        int id = Integer.parseInt(sc.nextLine());
        boolean ok = manager.deleteBook(id);
        System.out.println(ok ? "Deleted successfully." : "Delete failed or ID not found.");
    }
}
